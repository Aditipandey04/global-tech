const emailSubject = document.getElementById("emailSubject").value;
const emailBody = document.getElementById("emailBody").value;

function send() {
    Email.send({
        Host: "smtp.gmail.com",
        Username: "rajnishsingh44@gmail.com",
        Password: "Oracle@123#",
        To: "rajnishsingh95@yahoo.com.com",
        From: "rajnishsingh44@gmail.com",
        Subject: emailSubject,
        Body: emailBody,
    }).then(
        message => alert("Sent successfully.")
    );
}